# Imports
import re

# Static Variables
PATH_INFO_REGEX = "^/[^/]*/rest/"

# Get Request Parameters
path_info = webletRequest.getParameter("rde-rd:path-info")

# Remove prefix from path_info
rest_path = re.sub(PATH_INFO_REGEX, "", path_info)

# Split rest path into parts
rest_path_parts = rest_path.split("/")

# Declare named rest path parts
style = ""
noun = ""
id = ""
extra = ""

# Get style
if (len(rest_path_parts) >= 1):
	style = rest_path_parts[0]

# Get noun
if (len(rest_path_parts) >= 2):
	noun = rest_path_parts[1]
	
# Get id
if (len(rest_path_parts) >= 3):
	id = rest_path_parts[2]

# Get the extra
if (len(rest_path_parts) >= 4):
	extra = "/".join(rest_path_parts[3:])

# Output variables as XML
result = """
	<result>
		<style>%(style)s</style>
		<noun>%(noun)s</noun>
		<id>%(id)s</id>
		<extra>%(extra)s</extra>
	</result>
	""" % locals()
