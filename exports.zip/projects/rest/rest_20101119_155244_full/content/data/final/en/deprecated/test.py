# Test
webletRequest.getParameter("test")
test = "test"
webletRequest.setParameter("test", "test")
result = "test"