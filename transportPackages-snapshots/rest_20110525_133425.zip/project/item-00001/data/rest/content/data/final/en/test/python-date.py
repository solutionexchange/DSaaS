# --------------------------------------------
# File: javapython.py 
# Author: JACK MARCZEWSKI & NAGIB SHAH (OPENTEXT WSG)
# Description: contains various math and date related functions/methods
# --------------------------------------------

# --------------------------------------------
# Imports: new libraries need to be imported as requried
# --------------------------------------------
import sys
import re
import string
from java.util import GregorianCalendar
from java.util import Calendar
from java.util import Date
from java.text import SimpleDateFormat
from java.text import DateFormat

# --------------------------------------------
# Functions
# --------------------------------------------

# main function to call other functions based on the "method" parameter
def callMethod(method):
    callResult = "required parameters not specified"
    # choose method to call
    if (method == "addDays"):
      if (param_exists("date") and param_exists("add_days")):
        callResult = addDays(date, add_days)
    elif (method == "compareDate"):
      if (param_exists("date1") and param_exists("date2")):
        callResult = compareDate(date1, date2)
    else:
      callResult = "required parameters not specified"
    # return result
    return callResult

# increment the specified date by the specified integer value (can be negative)
def addDays(date, add_days):
    date_format_init = "yyyy/MM/dd"
    if (param_exists("date_format")):
      date_format_init = date_format
    sdf = SimpleDateFormat(date_format_init)
    parsedDate = sdf.parse(date)
    cal = GregorianCalendar.getInstance()
    cal.setTime(parsedDate)
    cal.add(Calendar.DATE, int(add_days))
    newDate = sdf.format(cal.getTime())
    return newDate

# compare date 1 to date 2 and returns either true or false, date1 needs to be the current date and date 2 is the end date
def compareDate(date1, date2):
    result = "valid"
    date2 = str(date2)
    date2 = date2.replace(".","/")
    date_format_init = "dd/MM/yyyy"
    if (param_exists("date_format")):
      date_format_init = date_format
    sdf = SimpleDateFormat(date_format_init)
    currentDate = sdf.parse(date1)
    newDate = sdf.parse(date2)
    cal1 = GregorianCalendar.getInstance()
    cal2 = GregorianCalendar.getInstance()
    cal1.setTime(currentDate)
    cal2.setTime(newDate)
    if (cal1.after(cal2)): 
      result = str(webletRequest.setParameter("result","expired"))
    else:
      result = str(webletRequest.setParameter("result","valid"))
    return result

# check if parameter exists
def param_exists(param):
    return globals().has_key(param)

# --------------------------------------------
# Run Script
# --------------------------------------------

try:
    myResult = ""
    # call specified method, or "addDays" if not specified
    if (param_exists("method")):
      myResult = callMethod(method)
    else:
      myResult = callMethod("addDays")
    # return result
    result = myResult

except Exception, e:
    result = "An exception has occured: " + str(e)